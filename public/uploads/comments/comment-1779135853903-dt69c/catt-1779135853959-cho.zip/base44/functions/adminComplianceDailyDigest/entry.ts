import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Runs daily — sends a summary of open compliance flags to all admin users
Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);

  // Fetch all open (unresolved) flags
  const allFlags = await base44.asServiceRole.entities.ComplianceFlag.filter({ is_resolved: false });

  if (allFlags.length === 0) {
    return Response.json({ message: 'No open flags — digest skipped.' });
  }

  // Group by severity
  const bySeverity = { Critical: [], High: [], Medium: [], Low: [] };
  for (const f of allFlags) {
    const bucket = bySeverity[f.severity] || bySeverity.Low;
    bucket.push(f);
  }

  const severityOrder = ['Critical', 'High', 'Medium', 'Low'];

  // Build digest body
  const lines = [
    `Daily Compliance Digest — ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`,
    ``,
    `Total Open Flags: ${allFlags.length}`,
    `  • Critical: ${bySeverity.Critical.length}`,
    `  • High:     ${bySeverity.High.length}`,
    `  • Medium:   ${bySeverity.Medium.length}`,
    `  • Low:      ${bySeverity.Low.length}`,
    ``,
    `─────────────────────────────────────────`,
  ];

  for (const sev of severityOrder) {
    const flags = bySeverity[sev];
    if (flags.length === 0) continue;
    lines.push(``, `[${sev.toUpperCase()}] (${flags.length} flag${flags.length > 1 ? 's' : ''})`);
    for (const f of flags) {
      const flagType = f.flag_type?.replace(/([A-Z])/g, ' $1').trim() || '—';
      lines.push(`  • ${f.organization_name || '—'} | App: ${f.application_number || '—'} | ${flagType}`);
      if (f.description) lines.push(`    ${f.description}`);
    }
  }

  lines.push(``, `─────────────────────────────────────────`);
  lines.push(`Log in to the GMT Portal to review and resolve open flags.`);
  lines.push(`Grant Management System`);

  const emailBody = lines.join('\n');
  const subject = `Compliance Digest: ${allFlags.length} Open Flag${allFlags.length > 1 ? 's' : ''} — ${new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;

  // Fetch all admin users
  const admins = await base44.asServiceRole.entities.User.filter({ role: 'admin' });

  if (admins.length === 0) {
    return Response.json({ message: 'No admin users found.' });
  }

  await Promise.all(admins.map(admin =>
    base44.asServiceRole.integrations.Core.SendEmail({
      to: admin.email,
      subject,
      body: emailBody,
    })
  ));

  return Response.json({
    message: `Digest sent to ${admins.length} admin(s).`,
    open_flags: allFlags.length,
    admins_notified: admins.map(a => a.email),
  });
});