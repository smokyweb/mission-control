import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * SAM.gov UEI Validation Scheduler
 *
 * Checks each Organization's sam_uei by querying the SAM.gov public API.
 * Creates a ComplianceFlag and sends an admin email for any that are expired,
 * inactive, or not found.
 *
 * Can be triggered via scheduler (weekly) or manually by an admin.
 * SAM.gov public entity search: https://api.sam.gov/entity-information/v3/entities
 * Requires a SAM_GOV_API_KEY secret.
 */

const SAM_API_KEY = Deno.env.get('SAM_GOV_API_KEY');
const SAM_API_BASE = 'https://api.sam.gov/entity-information/v3/entities';

async function checkUei(uei) {
  if (!SAM_API_KEY) {
    // Without a key, return unknown — do not block
    return { status: 'unknown', reason: 'SAM_GOV_API_KEY not configured' };
  }

  const url = `${SAM_API_BASE}?ueiSAM=${encodeURIComponent(uei)}&api_key=${SAM_API_KEY}`;
  const res = await fetch(url, { headers: { Accept: 'application/json' } });

  if (!res.ok) {
    return { status: 'error', reason: `SAM API returned ${res.status}` };
  }

  const data = await res.json();
  const entities = data?.entityData || [];

  if (entities.length === 0) {
    return { status: 'not_found', reason: 'UEI not found in SAM.gov' };
  }

  const entity = entities[0];
  const regStatus = entity?.entityRegistration?.registrationStatus;
  const expirationDate = entity?.entityRegistration?.registrationExpirationDate;

  if (regStatus === 'Active') {
    return { status: 'active', expirationDate };
  }

  if (regStatus === 'Expired') {
    return { status: 'expired', reason: `Registration expired on ${expirationDate}`, expirationDate };
  }

  return { status: 'inactive', reason: `Registration status: ${regStatus}`, expirationDate };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Allow either scheduled (no user) or manual invocation by admin
    let user = null;
    try { user = await base44.auth.me(); } catch (_) {}
    if (user && user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const orgs = await base44.asServiceRole.entities.Organization.list();
    const orgsWithUei = orgs.filter(o => o.sam_uei && o.sam_uei.trim());

    const results = [];

    for (const org of orgsWithUei) {
      const check = await checkUei(org.sam_uei.trim());
      results.push({ org_id: org.id, org_name: org.name, uei: org.sam_uei, ...check });

      if (check.status === 'expired' || check.status === 'not_found' || check.status === 'inactive') {
        // Check if an unresolved flag already exists for this org
        const existing = await base44.asServiceRole.entities.ComplianceFlag.filter({
          application_id: org.id,
          flag_type: 'MissingDocument',
          is_resolved: false,
        });

        const alreadyFlagged = existing.some(f =>
          f.description?.includes('SAM.gov') && f.description?.includes(org.sam_uei)
        );

        if (!alreadyFlagged) {
          await base44.asServiceRole.entities.ComplianceFlag.create({
            application_id: org.id,
            application_number: org.name,
            organization_name: org.name,
            flag_type: 'MissingDocument',
            severity: check.status === 'not_found' ? 'Critical' : 'High',
            description: `SAM.gov UEI validation failed for ${org.name} (UEI: ${org.sam_uei}). Reason: ${check.reason || check.status}. Expiration: ${check.expirationDate || 'N/A'}.`,
            is_resolved: false,
          });

          // Email admin notification
          await base44.asServiceRole.integrations.Core.SendEmail({
            to: 'admin@nema.gov',
            subject: `SAM.gov UEI Alert — ${org.name}`,
            body: `Alert: The SAM.gov registration for ${org.name} (UEI: ${org.sam_uei}) has a compliance issue.\n\nStatus: ${check.status}\nReason: ${check.reason || '—'}\nExpiration: ${check.expirationDate || 'N/A'}\n\nPlease follow up with the subrecipient to renew their SAM.gov registration before issuing any further payments.\n\n— GMT Automated Compliance System`,
          });
        }
      }
    }

    const summary = {
      checked: orgsWithUei.length,
      active: results.filter(r => r.status === 'active').length,
      expired: results.filter(r => r.status === 'expired').length,
      not_found: results.filter(r => r.status === 'not_found').length,
      inactive: results.filter(r => r.status === 'inactive').length,
      unknown: results.filter(r => r.status === 'unknown' || r.status === 'error').length,
    };

    return Response.json({ success: true, summary, results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});