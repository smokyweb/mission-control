import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Phase 2 Risk-Based Automated Alerts
 * Checks:
 *  1. Procurement Risk: Equipment line items > $250k without CompetitiveBid or SoleSource
 *  2. EHP Risk: Construction projects approved > 30 days ago without an approved EHP document
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Allow scheduled (no-auth) or admin-triggered calls
    let isScheduled = false;
    try {
      const user = await base44.auth.me();
      if (user?.role !== 'admin') {
        return Response.json({ error: 'Forbidden' }, { status: 403 });
      }
    } catch {
      isScheduled = true; // called by scheduler
    }

    const results = { procurementFlags: 0, ehpFlags: 0 };

    // --- 1. Procurement Risk: line items > $250k without proper procurement tag ---
    const lineItems = await base44.asServiceRole.entities.FundingRequestLineItem.list('-created_date', 500);
    const highValueEquipment = lineItems.filter(item =>
      item.budget_category === 'Equipment' &&
      (item.amount || 0) > 250000 &&
      !['CompetitiveBid', 'SoleSource'].includes(item.procurement_method_override)
    );

    // Check parent funding requests for those items
    const frIds = [...new Set(highValueEquipment.map(i => i.funding_request_id))];
    for (const frId of frIds) {
      const frs = await base44.asServiceRole.entities.FundingRequest.filter({ id: frId });
      const fr = frs[0];
      if (!fr) continue;

      // Check if procurement method on funding request is compliant
      if (!fr.application_id) continue;
      const procMethod = fr.procurement_method;
      if (['CompetitiveBid', 'SoleSource'].includes(procMethod)) continue;

      // Check if flag already exists
      const existing = await base44.asServiceRole.entities.ComplianceFlag.filter({
        application_id: fr.application_id,
        flag_type: 'FinancialDiscrepancy',
        is_resolved: false,
      });
      const alreadyFlagged = existing.some(f => f.description?.includes('procurement') || f.description?.includes('$250k'));
      if (alreadyFlagged) continue;

      const items = highValueEquipment.filter(i => i.funding_request_id === frId);
      const total = items.reduce((s, i) => s + (i.amount || 0), 0);

      await base44.asServiceRole.entities.ComplianceFlag.create({
        application_id: fr.application_id,
        application_number: fr.application_number,
        organization_name: fr.organization_name,
        flag_type: 'FinancialDiscrepancy',
        description: `Procurement Risk: Equipment purchase of $${total.toLocaleString()} exceeds the $250,000 federal threshold without a Competitive Bid or Sole Source procurement method designation.`,
        severity: 'Critical',
        is_resolved: false,
      });

      await base44.asServiceRole.entities.AuditLog.create({
        user_email: 'risk-engine@system', user_name: 'Risk Engine',
        action: 'ProcurementRiskFlagged', entity_type: 'FundingRequest', entity_id: frId,
        description: `Auto-flagged procurement risk on FR ${fr.request_number} — equipment $${total.toLocaleString()} > $250k threshold`,
      });

      results.procurementFlags++;
    }

    // --- 2. EHP Risk: Construction projects approved > 30 days ago without approved EHP doc ---
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
    const approvedApps = await base44.asServiceRole.entities.Application.filter({ status: 'Approved' }, '-created_date', 300);

    const constructionApps = approvedApps.filter(app =>
      app.ehp_required === true &&
      app.ehp_status !== 'Approved' &&
      app.submitted_at &&
      app.submitted_at < thirtyDaysAgo
    );

    for (const app of constructionApps) {
      // Check if EHP approval doc exists
      const docs = await base44.asServiceRole.entities.Document.filter({
        application_id: app.id,
        review_status: 'Approved',
      });
      const hasEhpDoc = docs.some(d =>
        d.doc_type === 'Other' && (d.name?.toLowerCase().includes('ehp') || d.description?.toLowerCase().includes('ehp'))
      );
      if (hasEhpDoc) continue;

      // Check if flag already exists
      const existing = await base44.asServiceRole.entities.ComplianceFlag.filter({
        application_id: app.id,
        flag_type: 'MissingDocument',
        is_resolved: false,
      });
      const alreadyFlagged = existing.some(f => f.description?.toLowerCase().includes('ehp'));
      if (alreadyFlagged) continue;

      await base44.asServiceRole.entities.ComplianceFlag.create({
        application_id: app.id,
        application_number: app.application_number,
        organization_name: app.organization_name,
        flag_type: 'MissingDocument',
        description: `EHP Review Overdue: This construction project was approved more than 30 days ago (${new Date(app.submitted_at).toLocaleDateString()}) but no approved Environmental & Historic Preservation (EHP) document has been submitted.`,
        severity: 'High',
        is_resolved: false,
      });

      await base44.asServiceRole.entities.AuditLog.create({
        user_email: 'risk-engine@system', user_name: 'Risk Engine',
        action: 'EHPRiskFlagged', entity_type: 'Application', entity_id: app.id,
        description: `Auto-flagged EHP overdue risk for ${app.application_number}`,
      });

      results.ehpFlags++;
    }

    return Response.json({ success: true, ...results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});