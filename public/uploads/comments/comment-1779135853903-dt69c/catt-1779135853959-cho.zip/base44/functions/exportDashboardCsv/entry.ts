import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { applications } = await req.json();

    if (!applications || !Array.isArray(applications)) {
      return Response.json({ error: 'Invalid applications data' }, { status: 400 });
    }

    // Build CSV header
    const headers = [
      'Application Number',
      'Organization Name',
      'Program Code',
      'Project Title',
      'Status',
      'Requested Amount',
      'Awarded Amount',
      'Match Amount',
      'Total Expended',
      'Remaining Balance',
      'Submitted Date',
      'Performance Start',
      'Performance End',
    ];

    // Build CSV rows
    const rows = applications.map(app => [
      app.application_number || '',
      app.organization_name || '',
      app.program_code || '',
      app.project_title || '',
      app.status || '',
      app.requested_amount || '',
      app.awarded_amount || '',
      app.match_amount || '',
      app.total_expended || '',
      app.remaining_balance || '',
      app.submitted_at ? new Date(app.submitted_at).toLocaleDateString() : '',
      app.performance_start || '',
      app.performance_end || '',
    ]);

    // Combine headers and rows
    const csv = [
      headers.join(','),
      ...rows.map(row => row.map(cell => {
        // Escape quotes and wrap in quotes if needed
        const str = String(cell);
        return str.includes(',') || str.includes('"') ? `"${str.replace(/"/g, '""')}"` : str;
      }).join(',')),
    ].join('\n');

    return new Response(csv, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': 'attachment; filename=dashboard-export.csv',
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});