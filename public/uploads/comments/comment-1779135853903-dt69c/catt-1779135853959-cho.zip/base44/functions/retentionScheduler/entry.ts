import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const THREE_YEARS_MS = 3 * 365.25 * 24 * 60 * 60 * 1000;

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // This is a scheduled function — use service role
    const closedApps = await base44.asServiceRole.entities.Application.filter({
      status: 'Closed',
      flagged_for_retention: false,
    });

    const now = Date.now();
    const toFlag = closedApps.filter(app => {
      const closedAt = app.closed_at ? new Date(app.closed_at).getTime() : null;
      if (!closedAt) return false;
      return (now - closedAt) >= THREE_YEARS_MS;
    });

    let flaggedCount = 0;
    for (const app of toFlag) {
      await base44.asServiceRole.entities.Application.update(app.id, {
        flagged_for_retention: true,
        retention_flagged_at: new Date().toISOString(),
      });

      // Create a compliance flag for admin review
      await base44.asServiceRole.entities.ComplianceFlag.create({
        application_id: app.id,
        application_number: app.application_number,
        organization_name: app.organization_name,
        flag_type: 'MissingDocument',
        description: `Application ${app.application_number} has been closed for 3+ years (closed: ${app.closed_at?.split('T')[0]}). Review for long-term storage or deletion per state retention policy.`,
        severity: 'Low',
        is_resolved: false,
      });

      await base44.asServiceRole.entities.AuditLog.create({
        user_email: 'system',
        user_name: 'Retention Scheduler',
        action: 'RetentionFlagged',
        entity_type: 'Application',
        entity_id: app.id,
        description: `Application ${app.application_number} flagged for retention review (closed ${app.closed_at?.split('T')[0]})`,
      });

      flaggedCount++;
    }

    return Response.json({
      checked: closedApps.length,
      flagged: flaggedCount,
      message: `Retention check complete. Flagged ${flaggedCount} application(s) for review.`,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});