import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { url } = await req.json();
    if (!url) return Response.json({ error: 'Missing URL' }, { status: 400 });

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Analyze the grant program information from this URL: ${url}

Extract the following fields and return them as structured JSON:
- program_name: Full official name of the grant program
- program_code: Short acronym/code (e.g. HMGP, BRIC, SHSP). If not stated, create a logical abbreviation.
- description: A concise 2-3 sentence overview of the program's purpose and goals
- federal_agency: The federal agency administering the program (e.g. FEMA, HUD)
- cfda_number: The CFDA or Assistance Listing Number if available (format: XX.XXX)
- eligibility_summary: A concise summary of who is eligible to apply and key eligibility requirements

Return only the JSON object with these fields.`,
      add_context_from_internet: true,
      response_json_schema: {
        type: "object",
        properties: {
          program_name: { type: "string" },
          program_code: { type: "string" },
          description: { type: "string" },
          federal_agency: { type: "string" },
          cfda_number: { type: "string" },
          eligibility_summary: { type: "string" }
        },
        required: ["program_name", "description"]
      }
    });

    return Response.json(result);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});