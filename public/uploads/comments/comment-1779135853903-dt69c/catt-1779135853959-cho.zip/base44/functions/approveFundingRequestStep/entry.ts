import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { funding_request_id, step, action, notes } = await req.json();

    if (!funding_request_id || !step || !action) {
      return Response.json({ error: 'Missing required fields: funding_request_id, step, action' }, { status: 400 });
    }
    if (!['program_manager', 'finance_officer'].includes(step)) {
      return Response.json({ error: 'Invalid step. Must be program_manager or finance_officer' }, { status: 400 });
    }
    if (!['Approved', 'Rejected'].includes(action)) {
      return Response.json({ error: 'Invalid action. Must be Approved or Rejected' }, { status: 400 });
    }

    // Verify the user has the right role for this step
    const allowedRoles = step === 'program_manager'
      ? ['program_manager', 'admin']
      : ['finance_officer', 'admin'];

    if (!allowedRoles.includes(user.role)) {
      return Response.json({ error: `Forbidden: You must be a ${step.replace('_', ' ')} to perform this action` }, { status: 403 });
    }

    // Fetch the funding request
    const requests = await base44.asServiceRole.entities.FundingRequest.filter({ id: funding_request_id });
    if (!requests.length) return Response.json({ error: 'Funding request not found' }, { status: 404 });
    const fr = requests[0];

    if (!fr.requires_multi_step_approval) {
      return Response.json({ error: 'This request does not require multi-step approval' }, { status: 400 });
    }

    const now = new Date().toISOString();
    const updates = {};

    if (step === 'program_manager') {
      if (fr.payment_status !== 'PendingPMApproval') {
        return Response.json({ error: 'This request is not awaiting Program Manager approval' }, { status: 400 });
      }
      updates.pm_approval_status = action;
      updates.pm_approved_by = user.email;
      updates.pm_approved_at = now;
      updates.pm_notes = notes || '';

      if (action === 'Approved') {
        updates.payment_status = 'PendingFOApproval';
      } else {
        updates.payment_status = 'PaymentFailed';
      }
    } else {
      // finance_officer
      if (fr.payment_status !== 'PendingFOApproval') {
        return Response.json({ error: 'This request is not awaiting Finance Officer approval' }, { status: 400 });
      }
      if (fr.pm_approval_status !== 'Approved') {
        return Response.json({ error: 'Program Manager approval is required first' }, { status: 400 });
      }
      updates.fo_approval_status = action;
      updates.fo_approved_by = user.email;
      updates.fo_approved_at = now;
      updates.fo_notes = notes || '';

      if (action === 'Approved') {
        updates.payment_status = 'Paid';
        updates.payment_date = now.split('T')[0];
      } else {
        updates.payment_status = 'PaymentFailed';
      }
    }

    await base44.asServiceRole.entities.FundingRequest.update(funding_request_id, updates);

    // Audit log
    await base44.asServiceRole.entities.AuditLog.create({
      user_email: user.email,
      user_name: user.full_name || user.email,
      action: action,
      entity_type: 'FundingRequest',
      entity_id: funding_request_id,
      description: `${step === 'program_manager' ? 'Program Manager' : 'Finance Officer'} ${action.toLowerCase()} payment for ${fr.request_number}${notes ? `. Notes: ${notes}` : ''}`,
    });

    // Notify submitter
    await base44.asServiceRole.entities.Notification.create({
      user_email: fr.submitted_by,
      title: `Funding Request ${action} by ${step === 'program_manager' ? 'Program Manager' : 'Finance Officer'}`,
      message: `Your funding request ${fr.request_number} has been ${action.toLowerCase()} by the ${step === 'program_manager' ? 'Program Manager' : 'Finance Officer'}.${updates.payment_status === 'Paid' ? ' Payment has been processed.' : ''}`,
      type: 'fr_approval_step',
      entity_type: 'FundingRequest',
      entity_id: funding_request_id,
      is_read: false,
      link: '/my-funding-requests',
    });

    return Response.json({
      success: true,
      new_payment_status: updates.payment_status,
      message: `${step === 'program_manager' ? 'Program Manager' : 'Finance Officer'} ${action.toLowerCase()} successfully`,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});