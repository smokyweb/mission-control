import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Triggered by entity automation on ComplianceFlag create
Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const body = await req.json();

  const flag = body.data;
  if (!flag) {
    return Response.json({ error: 'No flag data in payload' }, { status: 400 });
  }

  // Find the application to get the subrecipient's email
  const apps = await base44.asServiceRole.entities.Application.filter({ id: flag.application_id });
  const app = apps[0];
  if (!app || !app.submitted_by) {
    return Response.json({ message: 'No application or submitter found, skipping.' });
  }

  const severityLabel = flag.severity || 'Unknown';
  const flagTypeLabel = flag.flag_type?.replace(/([A-Z])/g, ' $1').trim() || 'Compliance Issue';
  const appNumber = flag.application_number || app.application_number || '—';
  const orgName = flag.organization_name || app.organization_name || 'Your Organization';

  // Send email to subrecipient
  await base44.asServiceRole.integrations.Core.SendEmail({
    to: app.submitted_by,
    subject: `[${severityLabel}] Compliance Flag Issued — ${appNumber}`,
    body: `Dear ${orgName},\n\nA new compliance flag has been issued against your grant application.\n\nApplication: ${appNumber}\nFlag Type: ${flagTypeLabel}\nSeverity: ${severityLabel}\nDetails: ${flag.description || '—'}\n\nPlease log in to the GMT Portal to review this flag and take corrective action as soon as possible. Unresolved flags may affect your grant standing.\n\nIf you have questions, please contact your grant manager.\n\nGrant Management Team`,
  });

  // Create in-app notification
  await base44.asServiceRole.entities.Notification.create({
    user_email: app.submitted_by,
    title: `Compliance Flag: ${flagTypeLabel}`,
    message: `A ${severityLabel} compliance flag has been issued for application ${appNumber}. Please review and take action.`,
    type: 'compliance_flag',
    entity_type: 'ComplianceFlag',
    entity_id: flag.id,
    is_read: false,
    link: '/subrecipient-portal',
  });

  return Response.json({ message: 'Subrecipient notified.', sent_to: app.submitted_by });
});