import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const APP_BASE_URL = 'https://app.base44.com';

const STATUS_CONFIG = {
  Approved: {
    subject: '✅ Your Grant Application Has Been Approved',
    headline: 'Congratulations! Your application has been approved.',
    body: (app) => `We are pleased to inform you that your grant application <strong>${app.application_number || ''}</strong> for <strong>${app.project_title || 'your project'}</strong> has been <strong>approved</strong>.`,
    action: 'View Your Approved Application',
    path: '/my-applications',
    color: '#16a34a',
  },
  Denied: {
    subject: '❌ Your Grant Application Was Not Approved',
    headline: 'Application Not Approved',
    body: (app) => `We regret to inform you that your application <strong>${app.application_number || ''}</strong> for <strong>${app.project_title || 'your project'}</strong> was <strong>not approved</strong> at this time.`,
    action: 'View Application Details',
    path: '/my-applications',
    color: '#dc2626',
  },
  RevisionRequested: {
    subject: '📝 Revision Requested on Your Application',
    headline: 'Action Required: Revision Requested',
    body: (app) => `A revision has been requested on your application <strong>${app.application_number || ''}</strong> for <strong>${app.project_title || 'your project'}</strong>. Please review the feedback and resubmit.`,
    action: 'Review & Submit Revision',
    path: '/new-application',
    idParam: true,
    color: '#d97706',
  },
  UnderReview: {
    subject: '🔍 Your Application Is Now Under Review',
    headline: 'Your Application Is Being Reviewed',
    body: (app) => `Your application <strong>${app.application_number || ''}</strong> for <strong>${app.project_title || 'your project'}</strong> is now <strong>under review</strong> by our team. We will notify you of any updates.`,
    action: 'Track Application Status',
    path: '/my-applications',
    color: '#2563eb',
  },
};

const FUNDING_APPROVED_CONFIG = {
  subject: '💰 Your Funding Request Has Been Approved',
  headline: 'Funding Request Approved',
  body: (fr) => `Your funding request <strong>${fr.request_number || ''}</strong> of type <strong>${fr.request_type}</strong> has been <strong>approved</strong>${fr.amount_approved ? ` for <strong>$${Number(fr.amount_approved).toLocaleString()}</strong>` : ''}.`,
  action: 'View Funding Request',
  path: '/my-funding-requests',
  color: '#16a34a',
};

function buildEmailHtml({ headline, bodyHtml, actionLabel, actionUrl, color, notes }) {
  return `
<!DOCTYPE html>
<html>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding:40px 0;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
        <tr>
          <td style="background:${color};padding:28px 32px;">
            <p style="color:#ffffff;font-size:20px;font-weight:700;margin:0;">${headline}</p>
          </td>
        </tr>
        <tr>
          <td style="padding:32px;">
            <p style="color:#1e293b;font-size:15px;line-height:1.6;margin:0 0 24px;">${bodyHtml}</p>
            ${notes ? `<div style="background:#fef9c3;border-left:4px solid #eab308;padding:14px 16px;border-radius:6px;margin-bottom:24px;"><p style="margin:0;font-size:13px;color:#713f12;"><strong>Reviewer Notes:</strong> ${notes}</p></div>` : ''}
            <a href="${actionUrl}" style="display:inline-block;background:${color};color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-size:14px;font-weight:600;">${actionLabel}</a>
          </td>
        </tr>
        <tr>
          <td style="padding:20px 32px;background:#f8fafc;border-top:1px solid #e2e8f0;">
            <p style="margin:0;font-size:12px;color:#94a3b8;">This is an automated notification from the GMT Portal. Please do not reply to this email.</p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();

    const { event, data, old_data } = payload;

    // ── Application status change ──────────────────────────────────────────
    if (event?.entity_name === 'Application' && event?.type === 'update') {
      const app = data;
      const newStatus = app?.status;
      const oldStatus = old_data?.status;

      if (!newStatus || newStatus === oldStatus) {
        return Response.json({ skipped: true, reason: 'No status change' });
      }

      const config = STATUS_CONFIG[newStatus];
      if (!config) {
        return Response.json({ skipped: true, reason: `No config for status: ${newStatus}` });
      }

      const recipientEmail = app.submitted_by;
      if (!recipientEmail) {
        return Response.json({ skipped: true, reason: 'No submitted_by email' });
      }

      const actionUrl = newStatus === 'RevisionRequested'
        ? `${APP_BASE_URL}${config.path}?id=${app.id}`
        : `${APP_BASE_URL}${config.path}`;

      const html = buildEmailHtml({
        headline: config.headline,
        bodyHtml: config.body(app),
        actionLabel: config.action,
        actionUrl,
        color: config.color,
        notes: newStatus === 'RevisionRequested' ? app.revision_notes : null,
      });

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: recipientEmail,
        subject: config.subject,
        body: html,
      });

      // Also create an in-app notification
      await base44.asServiceRole.entities.Notification.create({
        user_email: recipientEmail,
        title: config.subject.replace(/^[\p{Emoji}\s]+/u, '').trim(),
        message: `Application ${app.application_number || ''} status changed to ${newStatus}.`,
        type: 'application_status',
        entity_type: 'Application',
        entity_id: app.id,
        is_read: false,
        link: actionUrl,
      });

      return Response.json({ sent: true, to: recipientEmail, status: newStatus });
    }

    // ── Funding request approved ───────────────────────────────────────────
    if (event?.entity_name === 'FundingRequest' && event?.type === 'update') {
      const fr = data;
      const newStatus = fr?.status;
      const oldStatus = old_data?.status;

      if (newStatus !== 'Approved' || oldStatus === 'Approved') {
        return Response.json({ skipped: true, reason: 'Not a new approval' });
      }

      const recipientEmail = fr.submitted_by;
      if (!recipientEmail) {
        return Response.json({ skipped: true, reason: 'No submitted_by email' });
      }

      const actionUrl = `${APP_BASE_URL}${FUNDING_APPROVED_CONFIG.path}`;
      const cfg = FUNDING_APPROVED_CONFIG;

      const html = buildEmailHtml({
        headline: cfg.headline,
        bodyHtml: cfg.body(fr),
        actionLabel: cfg.action,
        actionUrl,
        color: cfg.color,
      });

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: recipientEmail,
        subject: cfg.subject,
        body: html,
      });

      await base44.asServiceRole.entities.Notification.create({
        user_email: recipientEmail,
        title: 'Funding Request Approved',
        message: `Your funding request ${fr.request_number || ''} has been approved${fr.amount_approved ? ` for $${Number(fr.amount_approved).toLocaleString()}` : ''}.`,
        type: 'funding_approved',
        entity_type: 'FundingRequest',
        entity_id: fr.id,
        is_read: false,
        link: actionUrl,
      });

      return Response.json({ sent: true, to: recipientEmail, status: 'Approved' });
    }

    return Response.json({ skipped: true, reason: 'Unhandled event type' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});