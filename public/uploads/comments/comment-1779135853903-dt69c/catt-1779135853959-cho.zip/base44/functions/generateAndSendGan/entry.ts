import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

function populateTemplate(body, app) {
  if (!body) return '';
  const fmt = (n) => n ? `$${Number(n).toLocaleString()}` : '—';
  const map = {
    '{{organization_name}}': app.organization_name || '—',
    '{{application_number}}': app.application_number || '—',
    '{{project_title}}': app.project_title || '—',
    '{{program_code}}': app.program_code || '—',
    '{{program_name}}': app.program_name || '—',
    '{{nofo_title}}': app.nofo_title || '—',
    '{{requested_amount}}': fmt(app.requested_amount),
    '{{awarded_amount}}': fmt(app.awarded_amount),
    '{{match_amount}}': fmt(app.match_amount),
    '{{performance_start}}': app.performance_start || '—',
    '{{performance_end}}': app.performance_end || '—',
    '{{submitted_by}}': app.submitted_by || '—',
    '{{today_date}}': new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
  };
  return body.replace(/\{\{[^}]+\}\}/g, (m) => map[m] || m);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { application_id } = await req.json();
    if (!application_id) {
      return Response.json({ error: 'application_id is required' }, { status: 400 });
    }

    // 1. Fetch the application
    const applications = await base44.asServiceRole.entities.Application.filter({ id: application_id });
    const app = applications[0];
    if (!app) {
      return Response.json({ error: `Application ${application_id} not found` }, { status: 404 });
    }

    // 2. Fetch the most recent active GAN template
    const templates = await base44.asServiceRole.entities.DocumentTemplate.filter(
      { doc_type: 'Grant Award Notice', is_active: true },
      '-created_date',
      1
    );
    if (!templates || templates.length === 0) {
      console.error('No active Grant Award Notice template found.');
      return Response.json({ error: 'No active Grant Award Notice template found. Please create one in Document Templates first.' }, { status: 404 });
    }
    const template = templates[0];

    // 3. Populate the template body
    const populatedBody = populateTemplate(template.template_body || '', app);

    // 4. Create GeneratedDocument record
    const generatedDoc = await base44.asServiceRole.entities.GeneratedDocument.create({
      template_id: template.id,
      template_name: template.name,
      doc_type: template.doc_type,
      application_id: app.id,
      application_number: app.application_number,
      organization_id: app.organization_id,
      organization_name: app.organization_name,
      populated_body: populatedBody,
      file_url: template.file_url || '',
      file_name: template.file_name || '',
      sent_by: user.email,
      sent_at: new Date().toISOString(),
      status: 'Pending Signature',
    });

    // 5. Create a Task for the subrecipient
    await base44.asServiceRole.entities.Task.create({
      application_id: app.id,
      application_number: app.application_number,
      organization_id: app.organization_id,
      organization_name: app.organization_name,
      type: 'Action',
      title: 'Review and Sign Grant Award Notice',
      description: `Your Grant Award Notice (GAN) for application ${app.application_number} is ready for your review and signature. Please log in to the portal, go to your Documents Inbox, and complete the e-signature for the document titled "${template.name}".`,
      assigned_to: app.submitted_by,
      status: 'Open',
      priority: 'High',
    });

    // 6. Send email notification
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: app.submitted_by,
      subject: `Action Required: Grant Award Notice Ready for Signature — ${app.application_number}`,
      body: `Dear ${app.organization_name},\n\nYour Grant Award Notice (GAN) for application ${app.application_number} is ready for your review and electronic signature.\n\nApplication: ${app.application_number}\nProgram: ${app.program_code || '—'} ${app.program_name ? '— ' + app.program_name : ''}\nAwarded Amount: ${app.awarded_amount ? '$' + Number(app.awarded_amount).toLocaleString() : '—'}\nPerformance Period: ${app.performance_start || '—'} to ${app.performance_end || '—'}\n\nTo complete the process:\n1. Log in to the GMT Portal\n2. Navigate to your Documents Inbox\n3. Find the document "${template.name}" and click Review & Sign\n4. Review the GAN carefully and provide your electronic signature\n\nThis signature is required before your award can be processed. If you have any questions, please contact your program manager.\n\nThank you,\nGrant Management Team`,
    });

    // 7. Create in-portal notification
    await base44.asServiceRole.entities.Notification.create({
      user_email: app.submitted_by,
      title: `Grant Award Notice Ready for Signature — ${app.application_number}`,
      message: `Your GAN for application ${app.application_number} has been issued and requires your electronic signature. Please visit your Documents Inbox to review and sign.`,
      type: 'gan_signature',
      entity_type: 'GeneratedDocument',
      entity_id: generatedDoc.id,
      is_read: false,
      link: '/my-applications',
    });

    return Response.json({
      success: true,
      message: `GAN generated and sent to ${app.submitted_by} for signature.`,
      generated_document_id: generatedDoc.id,
    });

  } catch (error) {
    console.error('generateAndSendGan error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});