import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();

    const { event, data } = payload;

    // Only handle newly submitted amendments
    if (event?.type !== 'create' && data?.status !== 'Submitted') {
      return Response.json({ skipped: true });
    }

    const amendment = data;
    if (!amendment?.application_id) {
      return Response.json({ skipped: true, reason: 'No application_id' });
    }

    // Fetch the parent application to find the assigned reviewer / grant manager
    const application = await base44.asServiceRole.entities.Application.get(amendment.application_id);
    if (!application) {
      return Response.json({ skipped: true, reason: 'Application not found' });
    }

    // Find admin users to notify (grant managers / state admins)
    const allUsers = await base44.asServiceRole.entities.User.list();
    const grantManagers = allUsers.filter(u => u.role === 'admin');

    if (grantManagers.length === 0) {
      return Response.json({ skipped: true, reason: 'No admin users found' });
    }

    const netChangeLabel = amendment.net_change != null
      ? `${amendment.net_change >= 0 ? '+' : ''}$${Math.abs(amendment.net_change).toLocaleString('en-US', { minimumFractionDigits: 2 })}`
      : 'N/A';

    const originalLabel = amendment.original_total != null
      ? `$${amendment.original_total.toLocaleString('en-US', { minimumFractionDigits: 2 })}`
      : 'N/A';

    const proposedLabel = amendment.proposed_total != null
      ? `$${amendment.proposed_total.toLocaleString('en-US', { minimumFractionDigits: 2 })}`
      : 'N/A';

    const reviewLink = `https://app.base44.com/budget-amendments`;

    const emailBody = `A new budget amendment has been submitted and requires your review.

Amendment Details:
  Amendment #:     ${amendment.amendment_number || 'N/A'}
  Organization:    ${amendment.organization_name || 'N/A'}
  Application #:   ${amendment.application_number || 'N/A'}
  Submitted By:    ${amendment.submitted_by || 'N/A'}
  Current Budget:  ${originalLabel}
  Proposed Budget: ${proposedLabel}
  Net Change:      ${netChangeLabel}

Justification:
${amendment.justification || 'No justification provided.'}

To review this amendment, please visit the Budget Amendments dashboard:
${reviewLink}

This is an automated notification from the Grant Management Portal.`;

    // Send email to all grant managers
    const emailPromises = grantManagers.map(gm =>
      base44.asServiceRole.integrations.Core.SendEmail({
        to: gm.email,
        subject: `Budget Amendment Submitted – ${amendment.amendment_number || amendment.application_number}`,
        body: emailBody,
      })
    );

    await Promise.all(emailPromises);

    // Also create in-app notifications
    const notifPromises = grantManagers.map(gm =>
      base44.asServiceRole.entities.Notification.create({
        user_email: gm.email,
        title: 'Budget Amendment Submitted',
        message: `${amendment.organization_name} submitted amendment ${amendment.amendment_number} (net change: ${netChangeLabel}) for application ${amendment.application_number}.`,
        type: 'amendment_submitted',
        entity_type: 'BudgetAmendment',
        entity_id: amendment.id,
        is_read: false,
        link: '/budget-amendments',
      })
    );

    await Promise.all(notifPromises);

    return Response.json({
      success: true,
      notified: grantManagers.length,
      amendment_number: amendment.amendment_number,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});