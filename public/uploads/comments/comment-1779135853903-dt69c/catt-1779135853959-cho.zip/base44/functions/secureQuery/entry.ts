import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * RLS-enforced data gateway.
 *
 * POST body: { entity, filters?, sort?, limit? }
 *
 * Access tiers:
 *  federal_admin / federal_officer  → full visibility, no scope restriction
 *  admin / reviewer (state)         → restricted to org records whose state === user.scope_state
 *  user (subrecipient)              → restricted to own organization_id only
 *
 * Entity access matrix:
 *  Application         org → organization_id | state → (filtered post-fetch via org list)
 *  FundingRequest      org → organization_id | state → filtered via org list
 *  ReportSchedule      org → application_id (via apps) | state → filtered via org list
 *  ProgressReport      org → application_id (via apps) | state → filtered via org list
 *  ComplianceFlag      org → application_id (via apps) | state → organization_name in org names
 *  Document            org → organization_id | state → organization_id in org ids
 *  Milestone           org → organization_id | state → organization_id in org ids
 *  Message             org → application_id (via apps) | state → filtered via org list
 *  Notification        all → user_email === caller email (always personal)
 *  Organization        org → own org only | state → state === scope_state
 *  AuditLog            org → forbidden | state → all (within state context)
 */

const ENTITY_WHITELIST = [
  'Application', 'FundingRequest', 'ReportSchedule', 'ProgressReport',
  'ComplianceFlag', 'Document', 'Milestone', 'Message', 'Notification',
  'Organization', 'AuditLog', 'ApplicationBudget', 'ApplicationReview',
  'FundingRequestLineItem',
];

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const user = await base44.auth.me();

  if (!user) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const body = await req.json();
  const { entity, filters = {}, sort = '-created_date', limit = 100 } = body;

  if (!entity || !ENTITY_WHITELIST.includes(entity)) {
    return Response.json({ error: `Entity '${entity}' is not queryable via this endpoint.` }, { status: 400 });
  }

  const role = user.role;
  const db = base44.asServiceRole.entities;

  // ── Federal users: unrestricted ───────────────────────────────────────────
  if (role === 'federal_admin' || role === 'federal_officer') {
    const data = await db[entity].filter(filters, sort, limit);
    return Response.json({ data, scope: 'federal', count: data.length });
  }

  // ── Subrecipient (org-level) ──────────────────────────────────────────────
  if (role === 'user') {
    const orgId = user.organization_id;
    if (!orgId) {
      return Response.json({ error: 'Your account is not linked to an organization.' }, { status: 403 });
    }

    // Notification: always personal
    if (entity === 'Notification') {
      const data = await db.Notification.filter({ ...filters, user_email: user.email }, sort, limit);
      return Response.json({ data, scope: 'org', count: data.length });
    }

    // AuditLog: subrecipients have no access
    if (entity === 'AuditLog') {
      return Response.json({ error: 'Forbidden: subrecipients cannot access audit logs.' }, { status: 403 });
    }

    // For entities that use organization_id directly
    if (['Application', 'FundingRequest', 'Document', 'Milestone', 'Organization'].includes(entity)) {
      const merged = entity === 'Organization'
        ? { ...filters, id: orgId }
        : { ...filters, organization_id: orgId };
      const data = await db[entity].filter(merged, sort, limit);
      return Response.json({ data, scope: 'org', count: data.length });
    }

    // For entities that hang off applications — resolve app ids first
    if (['ReportSchedule', 'ProgressReport', 'ComplianceFlag', 'Message',
         'ApplicationBudget', 'ApplicationReview', 'FundingRequestLineItem'].includes(entity)) {
      const apps = await db.Application.filter({ organization_id: orgId }, '-created_date', 500);
      const appIds = apps.map(a => a.id);

      if (appIds.length === 0) return Response.json({ data: [], scope: 'org', count: 0 });

      let all = await db[entity].filter(filters, sort, 500);

      // Filter to records belonging to the org's applications
      const fkField = entity === 'ApplicationBudget' || entity === 'ApplicationReview'
        ? 'application_id'
        : entity === 'FundingRequestLineItem'
          ? 'funding_request_id'
          : 'application_id';

      if (entity === 'FundingRequestLineItem') {
        const frs = await db.FundingRequest.filter({ organization_id: orgId }, '-created_date', 500);
        const frIds = frs.map(r => r.id);
        all = all.filter(r => frIds.includes(r.funding_request_id));
      } else {
        all = all.filter(r => appIds.includes(r[fkField]));
      }

      return Response.json({ data: all.slice(0, limit), scope: 'org', count: all.length });
    }

    return Response.json({ error: 'Entity not accessible.' }, { status: 403 });
  }

  // ── State users (admin / reviewer / isc_admin) ────────────────────────────
  if (role === 'admin' || role === 'reviewer' || role === 'isc_admin') {
    const scopeState = user.scope_state;

    // Notification: always personal
    if (entity === 'Notification') {
      const data = await db.Notification.filter({ ...filters, user_email: user.email }, sort, limit);
      return Response.json({ data, scope: 'state', count: data.length });
    }

    // If no scope_state set, fall back to full state-level read (legacy accounts)
    if (!scopeState) {
      const data = await db[entity].filter(filters, sort, limit);
      return Response.json({ data, scope: 'state_unscoped', count: data.length });
    }

    // Resolve all orgs in this state
    const stateOrgs = await db.Organization.filter({ state: scopeState }, '-created_date', 500);
    const stateOrgIds = stateOrgs.map(o => o.id);
    const stateOrgNames = stateOrgs.map(o => o.name);

    if (entity === 'Organization') {
      const data = stateOrgs.filter(o => {
        return Object.entries(filters).every(([k, v]) => o[k] === v);
      });
      return Response.json({ data: data.slice(0, limit), scope: 'state', count: data.length });
    }

    // Entities that carry organization_id
    if (['Application', 'FundingRequest', 'Document', 'Milestone'].includes(entity)) {
      let all = await db[entity].filter(filters, sort, 1000);
      all = all.filter(r => stateOrgIds.includes(r.organization_id));
      return Response.json({ data: all.slice(0, limit), scope: 'state', count: all.length });
    }

    // AuditLog: state admins can see all within context (no state field — return all for now)
    if (entity === 'AuditLog') {
      if (role !== 'admin') {
        return Response.json({ error: 'Forbidden: only state admins can access audit logs.' }, { status: 403 });
      }
      const data = await db.AuditLog.filter(filters, sort, limit);
      return Response.json({ data, scope: 'state', count: data.length });
    }

    // Entities that hang off applications
    if (['ReportSchedule', 'ProgressReport', 'ComplianceFlag', 'Message',
         'ApplicationBudget', 'ApplicationReview'].includes(entity)) {
      // Get all apps in scope
      const stateApps = await db.Application.filter({}, '-created_date', 2000);
      const scopedApps = stateApps.filter(a => stateOrgIds.includes(a.organization_id));
      const scopedAppIds = scopedApps.map(a => a.id);

      if (scopedAppIds.length === 0) return Response.json({ data: [], scope: 'state', count: 0 });

      let all = await db[entity].filter(filters, sort, 2000);

      if (entity === 'ComplianceFlag') {
        // ComplianceFlag uses organization_name (denormalized)
        all = all.filter(r => stateOrgNames.includes(r.organization_name) || scopedAppIds.includes(r.application_id));
      } else {
        all = all.filter(r => scopedAppIds.includes(r.application_id));
      }

      return Response.json({ data: all.slice(0, limit), scope: 'state', count: all.length });
    }

    if (entity === 'FundingRequestLineItem') {
      const frs = await db.FundingRequest.filter({}, '-created_date', 1000);
      const scopedFrs = frs.filter(r => stateOrgIds.includes(r.organization_id));
      const frIds = scopedFrs.map(r => r.id);
      let all = await db.FundingRequestLineItem.filter(filters, sort, 1000);
      all = all.filter(r => frIds.includes(r.funding_request_id));
      return Response.json({ data: all.slice(0, limit), scope: 'state', count: all.length });
    }

    return Response.json({ error: 'Entity not accessible.' }, { status: 403 });
  }

  return Response.json({ error: 'Forbidden' }, { status: 403 });
});