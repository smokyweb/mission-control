import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import JSZip from 'npm:jszip@3.10.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || (user.role !== 'admin' && user.role !== 'reviewer' && user.role !== 'federal_admin')) {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { application_id } = await req.json();
    if (!application_id) {
      return Response.json({ error: 'application_id is required' }, { status: 400 });
    }

    // Fetch application and related documents
    const [app, allDocs] = await Promise.all([
      base44.asServiceRole.entities.Application.filter({ id: application_id }),
      base44.asServiceRole.entities.Document.filter({ application_id }),
    ]);

    const application = app[0];
    if (!application) {
      return Response.json({ error: 'Application not found' }, { status: 404 });
    }

    const zip = new JSZip();

    // 1. Application summary as JSON
    const summary = {
      application_number: application.application_number,
      organization_name: application.organization_name,
      project_title: application.project_title,
      program_code: application.program_code,
      grant_number: application.grant_number,
      status: application.status,
      requested_amount: application.requested_amount,
      awarded_amount: application.awarded_amount,
      performance_start: application.performance_start,
      performance_end: application.performance_end,
      submitted_at: application.submitted_at,
      closed_at: application.closed_at,
      project_narrative: application.project_narrative,
      work_plan: application.work_plan,
    };
    zip.file('application_summary.json', JSON.stringify(summary, null, 2));

    // 2. Manifest of all documents
    const manifest = allDocs.map(d => ({
      name: d.name,
      doc_type: d.doc_type,
      uploaded_by: d.uploaded_by,
      uploaded_at: d.uploaded_at,
      review_status: d.review_status,
      file_url: d.file_url,
    }));
    zip.file('document_manifest.json', JSON.stringify(manifest, null, 2));

    // 3. Fetch and bundle qualifying documents by type
    const AUDIT_TYPES = ['Invoice', 'FinalReport', 'Contract', 'BudgetJustification', 'MatchDocumentation', 'PerformanceEvidence'];
    const auditDocs = allDocs.filter(d => AUDIT_TYPES.includes(d.doc_type) && d.file_url);

    const docFolder = zip.folder('documents');
    const fetchResults = await Promise.allSettled(
      auditDocs.map(async (doc) => {
        const resp = await fetch(doc.file_url);
        if (!resp.ok) return;
        const buffer = await resp.arrayBuffer();
        const ext = doc.file_url.split('.').pop().split('?')[0] || 'bin';
        const safeName = `${doc.doc_type}_${doc.name?.replace(/[^a-zA-Z0-9._-]/g, '_')}.${ext}`;
        docFolder.file(safeName, buffer);
      })
    );

    // 4. Generate zip as base64
    const zipBuffer = await zip.generateAsync({ type: 'uint8array' });

    // Log audit trail
    await base44.asServiceRole.entities.AuditLog.create({
      user_email: user.email,
      user_name: user.full_name,
      action: 'ExportAuditPackage',
      entity_type: 'Application',
      entity_id: application_id,
      description: `Admin exported audit package for application ${application.application_number}`,
    });

    return new Response(zipBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="audit_package_${application.application_number || application_id}.zip"`,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});