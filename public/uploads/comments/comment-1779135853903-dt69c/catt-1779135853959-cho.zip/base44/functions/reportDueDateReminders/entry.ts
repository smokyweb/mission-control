import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const user = await base44.auth.me();

  if (user?.role !== 'admin') {
    return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
  }

  const today = new Date();
  const targetDate = new Date(today);
  targetDate.setDate(today.getDate() + 7);
  const targetStr = targetDate.toISOString().split('T')[0];

  // Fetch all pending report schedules due in exactly 7 days
  const schedules = await base44.asServiceRole.entities.ReportSchedule.filter({ status: 'Pending' });
  const due = schedules.filter(s => s.due_date === targetStr);

  if (due.length === 0) {
    return Response.json({ message: 'No reminders to send today.', count: 0 });
  }

  const results = [];

  for (const schedule of due) {
    // Find the application to get the submitter email
    const apps = await base44.asServiceRole.entities.Application.filter({ id: schedule.application_id });
    const app = apps[0];
    if (!app || !app.submitted_by) continue;

    const reportLabel = `${schedule.report_type} Report`;
    const periodLabel = schedule.period_start && schedule.period_end
      ? ` for the period ${schedule.period_start} – ${schedule.period_end}`
      : '';

    // Send email
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: app.submitted_by,
      subject: `Reminder: ${reportLabel} Due in 7 Days — ${schedule.application_number || app.application_number}`,
      body: `Dear ${schedule.organization_name || app.organization_name},\n\nThis is a friendly reminder that your ${reportLabel}${periodLabel} is due on ${schedule.due_date}.\n\nApplication: ${schedule.application_number || app.application_number}\nProgram: ${schedule.program_code || app.program_code || '—'}\nDue Date: ${schedule.due_date}\n\nPlease log in to the GMT Portal to submit your report before the due date to remain in compliance.\n\nThank you,\nGrant Management Team`,
    });

    // Create in-app notification
    await base44.asServiceRole.entities.Notification.create({
      user_email: app.submitted_by,
      title: `${reportLabel} Due in 7 Days`,
      message: `Your ${reportLabel} for application ${schedule.application_number || app.application_number} is due on ${schedule.due_date}.`,
      type: 'report_due',
      entity_type: 'ReportSchedule',
      entity_id: schedule.id,
      is_read: false,
      link: '/my-reports',
    });

    results.push({ schedule_id: schedule.id, sent_to: app.submitted_by });
  }

  return Response.json({ message: `Sent ${results.length} reminder(s).`, count: results.length, results });
});